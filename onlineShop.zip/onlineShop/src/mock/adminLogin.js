export default {
  'post|/adminLogin': ({username, psw}) => {
    return {
      status: 200,
      message: 'success'
    }
  }
}
